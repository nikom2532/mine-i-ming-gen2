<?php
// cleanup unsubmitted imagery
if(!session_id()) { session_start(); }				// start session

?>